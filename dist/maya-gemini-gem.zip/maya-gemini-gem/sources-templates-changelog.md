## File: sources/README.md

# Religious source material

This package includes two openly licensed texts: the World English Bible (public domain) in christian/world-english-bible/ and the ClearQuran Allah Edition by Talal Itani (CC BY-ND 4.0) in islam/clearquran-allah-edition/. It does not include the NKJV or a Grail Message text. The folders christian/, grail-message/, and islam/ are reserved for source material the owner is authorized to use. Do not commit full copyrighted books or translations to a public repository or listing unless the applicable rights clearly allow that distribution.

When faith integration is welcome, Maya may consult accessible user-provided material first. A Google Drive link is usable only if the current assistant has an enabled, user-authorized Drive access path and can actually read the file. A link alone does not create a connector or guarantee access. Do not add an owner's Drive URL or credentials to a public skill package, and do not ask users to make private files link-accessible merely to make the skill work. Check a link's sharing scope before relying on it.

If a supplied text is unavailable or not authorized for the intended use, Maya may search online using tools actually available in the session. Suggested starting points are in links.md; prefer primary publishers or reputable text sources, identify the edition/translator, and say when a source could not be checked. Online availability does not itself grant permission to reproduce a work.

The owner's reviewed files identify these edition-specific rights notices:

- The Grail Message PDF identifies the English three-volume complete edition of In the Light of Truth: The Grail Message by Abd-ru-shin, translated from the German work. Its front matter states © 1990 Stiftung Gralsbotschaft, all rights reserved, and “only authorized edition.” This is not permission to redistribute the PDF or its text. Use official publisher material for citations and seek permission for reproduction.
- The NKJV Bible PDF identifies the New King James Version, © 1982 Thomas Nelson, Inc. Its front matter permits limited, accurate quotations up to 1,000 verses, subject to limits of less than 50% of a complete biblical book and less than 50% of the quoting work, with the stated acknowledgement. Follow the supplied edition's notice and check current publisher terms before broader use.
- The supplied ClearQuran Allah Edition PDF is translated by Talal Itani. Its front matter contains a CC BY-NC-ND notice. ClearQuran's current official download page states that its downloadable files use CC BY-ND 4.0, allows commercial use and distribution with attribution, requires the translation wording to remain unchanged, and says older non-commercial notices should be disregarded. Because the supplied PDF's front matter conflicts with the current page, prefer a current official download and its current terms rather than republishing that particular copy without confirming the license applies to it.

If neither a local text nor an online source can be checked, Maya may use general model knowledge for broad reflection only. She must say that exact wording and references were not verified. Keep quotations brief, name the translation/edition, and paraphrase longer passages. Never invent wording, verses, hadith grading, or page/lecture references.

---

## File: sources/links.md

# Suggested online starting points

These links help locate sources; they do not guarantee that a specific text or edition is accessible in every session. Check the page actually used, identify its translation/edition, and do not copy long passages into the public package. Do not publish owner-specific Drive links here.

- Bible translations: https://www.biblegateway.com/ (select and name the user's preferred translation where available). The reviewed New King James Version front matter identifies © 1982 Thomas Nelson, Inc. and gives limited quotation conditions; see sources/README.md.
- English Qur'an translations: https://quran.com/en (choose and identify a specific translation; translations may differ).
- ClearQuran English translation by Talal Itani: https://clearquran.com/download/ (official current downloads and terms). The Allah and God editions use different renderings for the Divine's name. Credit the translation as “Translation by Talal Itani, ClearQuran.com,” and keep translation wording unchanged when quoting or distributing text. See sources/README.md for the conflict between current terms and the older notice in the supplied PDF.
- Grail Message Foundation / publisher: https://us.grailmessage.com/ and https://grailmessage.com/ (prefer accessible publisher material; a full edition may require purchase or may not be available online). The Foundation describes its authorized final edition here: https://en-international.grailmessage.com/faq.
- Grail Message lecture list: https://grailmessage.com/in-the-light-of-truth-grail-message-content/ (publisher's overview of the 168-lecture, three-volume structure).
- Grail Message, “Fate”: https://en-international.grailmessage.com/in-the-light-of-truth-the-grail-message-volume-2-clothbound.html (publisher product page with a short excerpt for context; do not reproduce the excerpt in this package).
- Bundled World English Bible text: https://ebible.org/Scriptures/engwebp_vpl.zip (public domain; plain-text verse-per-line edition, downloaded 25 Nov 2026). Master copy: https://ebible.org/web/.
- Bundled ClearQuran Allah Edition text: https://d.clearquran.com/text/clearquran-txt-allah-edition.zip (CC BY-ND 4.0; publisher's Last Update October 9, 2026; downloaded 25 Nov 2026).

Record any additional source URL with its title, edition/translation, rights or license information if known, and access date. Do not put private client records or owner-specific Drive URLs here.

Sources reviewed: owner-provided PDFs and official source pages checked 25 Nov 2026.

---

## File: templates/overview.md

# Maya continuity overview — [name, pseudonym, or couple label]

Record consent: [scope/date]
Destination: [account/folder]
Session type: [individual/shared couple]
Preferred names and pronouns (optional):
How Maya should support me/us:
Faith preference (optional; user-defined):
Goals in my/our words:
Current focus:
Working summary/patterns (tentative; reviewed with user):
Strengths and supports:
Professional support/referral status (optional):
Current safety-plan summary (optional; store only where safe):
Last reviewed / corrections requested:


---

## File: templates/session-note.md

# Session note — [date] — [individual/couple label]

Consent covers this note: [yes/no]
Topic and goal in user's words:
Key events/thoughts/feelings shared (brief; attribute who said what):
Possible links/contributions explored (what is known, inferred, or uncertain):
Support/skills discussed and response:
What each person chose to own or try next:
Safety check/action (only if relevant and safe to store):
Next step and professional support recommended (if any):
User corrections:


---

## File: templates/referral-summary.md

# Referral summary — draft for review

This is a summary of information the person chose to share, not a clinical assessment or diagnosis.

Recipient/purpose:
Consent scope and date:
Reason for referral (person's words):
Current concerns and impact:
Relevant context (as shared):
Support tried and response:
Current safety concerns and actions (minimum necessary):
Questions/goals for the professional:
Corrections requested:
Approved to share with [named recipient]? [yes/no/date]


---

## File: CHANGELOG.md

# Changelog

Versions follow semantic versioning: major for incompatible behavior or structure, minor for backward-compatible capability, patch for corrections. Entries are drawn from the repository's commit history.

## Unreleased
- Added a Gemini Gem kit (`dist/maya-gemini-gem.zip`): nine Gemini-supported files that keep the package structure within Gemini's 10-file limit, with setup instructions. `scripts/build_gemini_kit.py` builds it and the GitHub Action rebuilds it with the single file. Skill content is unchanged.
- The Gemini kit carries the World English Bible New Testament, Psalms and Proverbs (unchanged verses) instead of the full Bible, which at about 1.1 million tokens exceeds Gemini's context window and fails to upload. For other books the Gem checks wording at ebible.org.
- The Gem instructions now include the full SKILL.md, unchanged, because Gems apply Instructions on every turn but only look up Knowledge files as needed.

## 1.3.0 — 2026-11-25
- Licensed the package under CC BY-NC 4.0 (`LICENSE`). Bundled scripture texts keep their own terms.
- Rewrote the skill description in SKILL.md frontmatter to present Maya as an AI therapy tool (not a licensed therapist or emergency service) and to say when to use it.
- README now opens with what Maya does and sample prompts, corrects the outdated note that no religious texts are bundled, and adds a License section.

## 1.2.0 — 2026-11-25
- Bundled two openly licensed texts, unchanged, with their publishers' notices: the World English Bible (public domain, eBible.org) in `sources/christian/world-english-bible/` and the ClearQuran Allah Edition by Talal Itani (CC BY-ND 4.0) in `sources/islam/clearquran-allah-edition/`.
- Updated the sources READMEs and links to record each text's edition, licence, credit line, and download date. The NKJV and Grail Message texts remain unbundled because their copyright does not allow redistribution.

## 1.1.0 — 2026-11-25
- Added a single-file edition (`dist/maya-therapeutic-support-single.md`) for platforms that accept only one skill file. It bundles SKILL.md with the safety spec, references, sources notes, templates, and this changelog, unchanged.
- Added `scripts/build_single_file.py` to regenerate the single file and a GitHub Action that rebuilds it on pushes to main.
- Grounded the Grail Message notes in the publisher's outline and added official Grail Message study references.
- Clarified conditional Google Drive source access.
- Identified the reviewed ClearQuran translation and its terms, the NKJV edition and its quotation guidance, and the reviewed Grail Message edition and rights.
- Added edition-specific religious source references and clarified religious source access and rights.

## 1.0.1 — 2026-11-24
- Documented and improved source-aware faith guidance.
- Added installation and upload instructions and documented the Skills CLI requirement.

## 1.0.0 — 2026-11-24
- Initial Maya therapeutic support skill package.
